﻿public interface IDamageable
{
    void GetHit(float power);
}
